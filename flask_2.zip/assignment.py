from flask import Flask, render_template
import random

app = Flask(__name__)

@app.route('/yahtzee', methods=['GET'])
def yahtzee():
    # empty_list = []
    # p = "<p> {} </p>"
    # for _ in range(6):
    #     i = random.randint(1,6)
    #     empty_list.append(p.format(i))
    # p = ""
    # for i in range(6):
    #     p += "<p> {} </p>".format(random.randint(1,6))

    p = "<p> {} </p>"
    our_list = [p.format(random.randint(1,6)) for i in range(6)]

    return "".join(our_list)

@app.route('/cowsay/<something>', methods=['GET'])
def cowsay(something):
    output = "{} Moooo!"
    return output.format(something)

@app.route('/moby/<number>', methods=['GET'])
def get_word(number):
    with open('wordlist.txt', 'r') as file_object:
        words = file_object.read()
        wordlist = words.split()
    return wordlist[int(number)-1]


if __name__ == "__main__":
    app.run(debug=True)