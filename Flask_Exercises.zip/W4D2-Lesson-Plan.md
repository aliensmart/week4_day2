## Week 4 Day 2

* Introduce & discuss virtualenv & pip freeze

* Write "hello world" in flask

* Demonstrate url_for, redirect, and render_template

* Discuss client-server model

* Discuss what traditional web programming is (server side html generation) and mention resources for learning that in Flask.

    * We've moved away from this in our curriculum, but a traditionally structured web application is a worthwhile phase-3 project. There's still a ton of that kind of work out there.

